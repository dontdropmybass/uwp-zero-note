﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zero_Note
{
    class Note
    {
        public string Title { get; set; }
        public string Body { get; set; }

        public Note(string Title, string Body)
        {
            this.Title = Title;
            this.Body = Body;
        }
    }
}
