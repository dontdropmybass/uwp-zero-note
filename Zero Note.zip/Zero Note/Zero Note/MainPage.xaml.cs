﻿using System;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;

namespace Zero_Note
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        MainPageData mpd = new MainPageData();
        string SaveName;

        public MainPage()
        {
            this.InitializeComponent();
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            ListView.SelectedItems.Clear();
            TextBoxBody.Text = "";
            TextBoxBody.IsReadOnly = false;
        }
        
        private async void SameNameSaveMessage()
        {
            ContentDialog sameName = new ContentDialog()
            {
                Title = "guhhhh",
                Content = "That name's taken",
                PrimaryButtonText = "Fine"
            };

            ContentDialogResult result = await sameName.ShowAsync();
        }

        private async void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            var saveTextBox = new TextBox { Width = 200, Height = 10 };
            SaveButton.IsEnabled = true;
            string body = TextBoxBody.Text;

            ContentDialog saveFileDialog = new ContentDialog()
            {
                Title = "Save As...",
                Content = saveTextBox,
                PrimaryButtonText = "Save",
                SecondaryButtonText = "Cancel"


            };

            ContentDialogResult result = await saveFileDialog.ShowAsync();

            if (result == ContentDialogResult.Primary)
            {
                SaveName = saveTextBox.Text;
                for (int i = 0; i < mpd.Notes.Count; i++)
                {
                    if (SaveName == mpd.Notes[i].Title)
                    {
                        SameNameSaveMessage();
                        return;
                    }
                    else
                    {
                        mpd.Notes.Add(new Note(SaveName, body));
                    }
                }
            }
        }

        private async void AboutButton_Click(object sender, RoutedEventArgs e)
        {
            ContentDialog about = new ContentDialog()
            {
                Title = "Shoot me",
                Content = "I just want to go to bed",
                PrimaryButtonText = "dfsghhhhhhhhhhhhhhhhhhhhhhhhhh"
            };

            ContentDialogResult result = await about.ShowAsync();
        }




        private async void ExitButton_Click(object sender, RoutedEventArgs e)
        {

            // Application.Current.Exit();


            ContentDialog exit = new ContentDialog()
            {
                Title = "exit?",
                Content = "Please just hit yes and close me.",
                PrimaryButtonText = "Yes",
                SecondaryButtonText = "No"
            };

            ContentDialogResult result = await exit.ShowAsync();

            if (result == ContentDialogResult.Primary)
            {
                Application.Current.Exit();
            }

        }


        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
            EditButton.IsEnabled = false;
            TextBoxBody.IsReadOnly = false;
            SaveButton.IsEnabled = true;
        }

        private async void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            ContentDialog delete = new ContentDialog()
            {
                Title = "Delete Note",
                Content = "Delete the note?",
                PrimaryButtonText = "Yes",
                SecondaryButtonText = "No"
            };

            ContentDialogResult result = await delete.ShowAsync();

            if (result == ContentDialogResult.Primary)
            {
                mpd.Notes.RemoveAt(ListView.SelectedIndex);
                ListView.SelectedItems.Clear();
                TextBoxBody.Text = "";
            }
        }

        private void ListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            EditButton.IsEnabled = true;
            SaveButton.IsEnabled = false;
            DeleteButton.IsEnabled = true;
            TextBoxBody.IsReadOnly = true;
            if (ListView.SelectedItem == null)
            {
                EditButton.IsEnabled = false;
                DeleteButton.IsEnabled = false;
                SaveButton.IsEnabled = true;
                TextBoxBody.IsReadOnly = false;
            }
        }
    }
}
