﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zero_Note
{
    class MainPageData : INotifyPropertyChanged
    {
        private string _noteBody = "";
        private string _noteName = "";

        public List<Note> _allNotes = new List<Note>();

        public string NoteBody
        {
            get { return _noteBody; }
            set
            {
                if (value == _noteBody)
                {
                    return;
                }
                _noteBody = value;

                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(NoteBody)));

            }
        }

        public string NoteName
        {
            get { return _noteName; }
            set
            {
                if (value == _noteName)
                {
                    return;
                }
                _noteName = value;

                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(NoteName)));

            }
        }

        public ObservableCollection<Note> Notes { get; set; }

        public MainPageData()
        {
            Notes = new ObservableCollection<Note>();

            /* Look at this code aesthetic    */
            /* The waterfall of sucky windows */
            Notes.Add(new Note("a", "Windows gives me headaches."));
            Notes.Add(new Note("bb", "Windows gives me headaches."));
            Notes.Add(new Note("ccc", "Windows gives me headaches."));
            Notes.Add(new Note("dddd", "Windows gives me headaches."));
            _allNotes.Add(new Note("a", "Windows gives me headaches."));
            _allNotes.Add(new Note("bb", "Windows gives me headaches."));
            _allNotes.Add(new Note("ccc", "Windows gives me headaches."));
            _allNotes.Add(new Note("dddd", "Windows gives me headaches."));

            PerformFiltering();
        }

        public Note _selectedNote;

        public event PropertyChangedEventHandler PropertyChanged;

        public Note SelectedNote
        {
            get { return _selectedNote; }
            set
            {
                _selectedNote = value;

                if (value == null)
                {
                    NoteBody = "please no";
                    NoteName = "nooo";
                }
                else
                {
                    NoteBody = value.Body;
                    NoteName = value.Title;
                }
            }
        }

        private string _filter;
        public string Filter
        {
            get { return _filter; }
            set
            {
                if (value == _filter)
                {
                    return;
                }
                _filter = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Filter)));

                PerformFiltering();

            }
        }
        private void PerformFiltering()
        {
            if (_filter == null)
                _filter = "";

            var lowerCaseFilter = Filter.ToLowerInvariant().Trim();

            var result =
                _allNotes.Where(d => d.Title.ToLowerInvariant()
                .Contains(lowerCaseFilter))
                .ToList();

            var toRemove = Notes.Except(result).ToList();

            foreach (var x in toRemove)
                Notes.Remove(x);

            var resultCount = result.Count;
            for (int i = 0; i < resultCount; i++)
            {
                var resultItem = result[i];
                if (i + 1 > Notes.Count || !Notes[i].Equals(resultItem))
                    Notes.Insert(i, resultItem);
            }
        }
    }
}
